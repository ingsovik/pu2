# Prosjekt 2

Gruppe 30:

_prosjekt2_ er mappa med prosjektet og inneholder mappene _public_ og _src_ med filkoden og tillegg. \
Det ligger en mer beskrivende README.md-fil i prosjektmappa.